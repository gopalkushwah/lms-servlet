package in.pandit.services;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.pandit.dao.UserDao;
import in.pandit.model.User;

/**
 * Servlet implementation class UpdateAdminBySuperAdmin
 */
@WebServlet("/UpdateUserBySuperAdmin")
public class UpdateUserBySuperAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String mobile = request.getParameter("mobile");
		String isAdmin = request.getParameter("isAdmin");
		String isSuperAdmin = request.getParameter("isSuperAdmin");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		HttpSession session = request.getSession();
		User user = new User();
		int id = (Integer)session.getAttribute("userId");
		String email = (String)session.getAttribute("userEmail");
		
		user.setName(name);
		user.setMobile(mobile);
		user.setEmail(email);
		user.setIsamdin(isAdmin);
		user.setIssuperadmin(isSuperAdmin);
		user.setGender(gender);
		user.setPassword(password);
		user.setId(id);
		boolean b = UserDao.updateUserInformation(user);
		if(b) {
			response.sendRedirect("allUsersSuperAdmin.jsp");
		}else {
			response.sendRedirect("allUsersSuperAdmin.jsp");
		}
		
	}

}
