package in.pandit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import in.pandit.model.Lead;
import in.pandit.persistance.DatabaseConnection;

public class LeadDao {
	private static final String GET_LEAD_BY_ID = "SELECT * FROM leads WHERE id=?";
	
	private static Connection con = DatabaseConnection.getConnection();
	private static PreparedStatement pst = null;
	
	public static Lead getLeadById(int leadId) {
		Lead lead = null;
		try {
			pst = con.prepareStatement(GET_LEAD_BY_ID);
			pst.setInt(1, leadId);
			ResultSet rst=  pst.executeQuery();
			lead = new Lead();
			while(rst.next()) {
				lead.setAddress(rst.getString("id"));
				lead.setCurrentowner(rst.getString("currentowner"));
				lead.setDate(rst.getString("date"));
				lead.setEmail(rst.getString("email"));
				lead.setId(rst.getInt("id"));
				lead.setMobile(rst.getString("mobile"));
				lead.setName(rst.getString("name"));
				lead.setOwner(rst.getString("owner"));
				lead.setPriority(rst.getString("priority"));
				lead.setSource(rst.getString("source"));
				lead.setStatus(rst.getString("status"));
				lead.setTime(rst.getString("time"));
				return lead;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lead;
	}
}
