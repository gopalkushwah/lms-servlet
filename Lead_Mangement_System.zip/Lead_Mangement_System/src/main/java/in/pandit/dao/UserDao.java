package in.pandit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import in.pandit.model.User;
import in.pandit.persistance.DatabaseConnection;

public class UserDao {
	private static final String GET_USER_BY_EMAIL = "SELECT * FROM users WHERE email=?";
	private static final String GET_NAME_BY_EMAIL = "SELECT name FROM users WHERE email=?";
	private static final String UPDATE_USER_INFORMATION = "UPDATE users SET name=?,email=?,gender=?,mobile=?,password=?,isadmin=?,issuperadmin=? WHERE id=?";
	private static final String ADD_USER_INFORMATION = "INSERT INTO users(email,gender,isadmin,issuperadmin,mobile,name,password) VALUES(?,?,?,?,?,?,?)";
	
	private static PreparedStatement pst = null;
	private static Connection con = DatabaseConnection.getConnection();
	public static User getUserByEmail(String email) {
		User user = null;
		try {
			pst = con.prepareStatement(GET_USER_BY_EMAIL);
			pst.setString(1, email);
			ResultSet rst = pst.executeQuery();
			user = new User();
			while(rst.next()) {
				user.setId(rst.getInt("id"));
				user.setEmail(rst.getString("email"));
				user.setGender(rst.getString("gender"));
				user.setIsamdin(rst.getString("isadmin"));
				user.setIssuperadmin(rst.getString("issuperadmin"));
				user.setMobile(rst.getString("mobile"));
				user.setName(rst.getString("name"));
				user.setPassword(rst.getString("password"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
	
	public static String getUserNameByEmail(String email) {
		try {
			pst = con.prepareStatement(GET_NAME_BY_EMAIL);
			pst.setString(1, email);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				return rst.getString("name");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "";
	}
	public static boolean updateUserInformation(User user) {
		try {
			pst = con.prepareStatement(UPDATE_USER_INFORMATION);
			pst.setString(1, user.getName());
			pst.setString(2, user.getEmail());
			pst.setString(3, user.getGender());
			pst.setString(4, user.getMobile());
			pst.setString(5, user.getPassword());
			pst.setString(6, user.getIsamdin());
			pst.setString(7, user.getIssuperadmin());
			pst.setInt(8, user.getId());
			pst.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	public static boolean addUser(User user) {
		try {
			pst = con.prepareStatement(ADD_USER_INFORMATION);
			pst.setString(1, user.getEmail());
			pst.setString(2, user.getGender());
			pst.setString(3, user.getIsamdin());
			pst.setString(4, user.getIssuperadmin());
			pst.setString(5, user.getMobile());
			pst.setString(6, user.getName());
			pst.setString(7, user.getPassword());
			pst.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
}
