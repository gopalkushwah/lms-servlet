package in.pandit.services;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.pandit.dao.LeadDao;
import in.pandit.model.Lead;


@WebServlet("/updateAdminAllLeads")
public class updateAdminAllLeads extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id").trim());
		String name = request.getParameter("name").trim();
		String email = request.getParameter("email").trim();
		String address = request.getParameter("address").trim();
		String mobile = request.getParameter("mobile").trim();
		String source = request.getParameter("source").trim();
		String date = request.getParameter("date").trim();
		String owner = request.getParameter("owner").trim();
		String currentOwner = request.getParameter("currentOwner").trim();
		String status = request.getParameter("status").trim();
		HttpSession session = request.getSession();
//		Lead leadByMobile = LeadDao.getLeadByMobile(mobile);
//		if(leadByMobile.getName()==null){
//			Lead leadByEmail = LeadDao.getLeadByEmail(email);
//			if(leadByEmail.getName()==null){
				Lead lead = new Lead();
				lead.setAddress(address);
				lead.setCurrentowner(currentOwner);
				lead.setDate(date);
				lead.setEmail(email);
				lead.setMobile(mobile);
				lead.setName(name);
				lead.setOwner(owner);
				lead.setSource(source);
				lead.setStatus(status);
				lead.setId(id);
				int insert = LeadDao.updateLead(lead);
				if(insert>0) {
					session.removeAttribute("updateMsg");
					pw.println("<script type=\"text/javascript\">");
					pw.println("alert('Lead updated successfully');");
					pw.println("</script>");
					session.setAttribute("updateMsg", "Lead updated successfully");
					response.sendRedirect("allLeads.jsp");
				}else {
					session.removeAttribute("updateMsg");
					pw.println("<script type=\"text/javascript\">");
					pw.println("alert('Something went wrong! try again');");
					pw.println("</script>");
					session.setAttribute("updateMsg", "Something went wrong! try again");
					response.sendRedirect("allLeads.jsp");
				}	
//			}else {
//				session.removeAttribute("updateMsg");
//				session.setAttribute("updateMsg", "Lead alredy available with same email!");
//				response.sendRedirect("allLeads.jsp");
//			}
//		}else {
//			session.removeAttribute("updateMsg");
//			session.setAttribute("updateMsg", "Lead alredy available with same mobile!");
//			response.sendRedirect("allLeads.jsp");
//		}
	}

}
